export interface Student {
  id: Number;
  name: String;
  email: String;
  gender: String;
  selected: boolean;
}
